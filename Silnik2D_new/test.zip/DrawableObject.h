/*
#ifndef DRAWABLEOBJECT_H
#define DRAWABLEOBJECT_H

#include <SFML/Graphics.hpp>

class DrawableObject {
public:
    virtual void draw(sf::RenderWindow& window) = 0;
};

#endif // DRAWABLEOBJECT_H
*/